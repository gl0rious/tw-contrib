cwRsync 5.4.1 Free - Rsync for Windows
October 2014, provided by Itefix - https://www.itefix.net/cwrsync

This archive contains a barebone distribution of Rsync for Windows.

Unzip archive contents to a directory, update the supplied batch file
cwrsync.cmd. That's all you need to be able to start rsync from a
command line.

NB! In the case you run into -meaningless- permission issues, please
consult our FAQ
https://www.itefix.net/content/permissions-filesdirectories-are-clutteredmixed

cwRsync FAQs can also be helpful - https://www.itefix.net/faq/cwrsync

We provide a paid version of cwRsync. Please consider purchasing if you want to:

- use Rsync via a GUI
- setup an Rsync server on Windows
- use Secure Channel Wizard for secure tunnelling with the best performance
- access to Rsync patched with time-limit, transliteration, ignore-case
  or no strict check of password file permissions
- use 64-bit distributions

See https://www.itefix.net/cwrsync for more information.

ENJOY RSYNC!!

Version information:
Rsync 3.1.1
Cygwin 1.7.32
OpenSSH 6.7p
OpenSSL 1.0.1i
